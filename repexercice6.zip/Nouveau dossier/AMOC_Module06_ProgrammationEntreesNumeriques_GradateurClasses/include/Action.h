#pragma once

class Action
{

public:
    virtual void executer();
};